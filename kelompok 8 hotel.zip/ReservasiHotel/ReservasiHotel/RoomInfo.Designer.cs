﻿namespace ReservasiHotel
{
    partial class RoomInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Datelbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Roomnametb = new System.Windows.Forms.TextBox();
            this.Roomnumtbl = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Yesradio = new Guna.UI2.WinForms.Guna2CustomRadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Noradio = new Guna.UI2.WinForms.Guna2CustomRadioButton();
            this.DeleteroomBtn = new System.Windows.Forms.Button();
            this.Editroombtn = new System.Windows.Forms.Button();
            this.AddroomBtn = new System.Windows.Forms.Button();
            this.reloadbtn = new System.Windows.Forms.Button();
            this.RoomSearchtb = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.RoomGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.RoomGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel1.Controls.Add(this.Datelbl);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1233, 111);
            this.panel1.TabIndex = 2;
            // 
            // Datelbl
            // 
            this.Datelbl.AutoSize = true;
            this.Datelbl.Font = new System.Drawing.Font("Swis721 Hv BT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Datelbl.Location = new System.Drawing.Point(1007, 63);
            this.Datelbl.Name = "Datelbl";
            this.Datelbl.Size = new System.Drawing.Size(101, 44);
            this.Datelbl.TabIndex = 2;
            this.Datelbl.Text = "Date";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Swis721 Hv BT", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(415, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(378, 48);
            this.label1.TabIndex = 1;
            this.label1.Text = "Room Information";
            // 
            // Roomnametb
            // 
            this.Roomnametb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Roomnametb.Location = new System.Drawing.Point(70, 243);
            this.Roomnametb.Multiline = true;
            this.Roomnametb.Name = "Roomnametb";
            this.Roomnametb.Size = new System.Drawing.Size(236, 30);
            this.Roomnametb.TabIndex = 7;
            this.Roomnametb.Text = "Room Name";
            // 
            // Roomnumtbl
            // 
            this.Roomnumtbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Roomnumtbl.Location = new System.Drawing.Point(70, 186);
            this.Roomnumtbl.Multiline = true;
            this.Roomnumtbl.Name = "Roomnumtbl";
            this.Roomnumtbl.Size = new System.Drawing.Size(236, 30);
            this.Roomnumtbl.TabIndex = 6;
            this.Roomnumtbl.Text = "Room Number";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Swis721 Hv BT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(66, 297);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 21);
            this.label2.TabIndex = 8;
            this.label2.Text = "Free";
            // 
            // Yesradio
            // 
            this.Yesradio.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Yesradio.CheckedState.BorderThickness = 0;
            this.Yesradio.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Yesradio.CheckedState.InnerColor = System.Drawing.Color.White;
            this.Yesradio.Location = new System.Drawing.Point(129, 295);
            this.Yesradio.Name = "Yesradio";
            this.Yesradio.Size = new System.Drawing.Size(25, 25);
            this.Yesradio.TabIndex = 9;
            this.Yesradio.Text = "guna2CustomRadioButton1";
            this.Yesradio.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Yesradio.UncheckedState.BorderThickness = 2;
            this.Yesradio.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.Yesradio.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Swis721 Hv BT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(160, 299);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 21);
            this.label3.TabIndex = 10;
            this.label3.Text = "YES";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Swis721 Hv BT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(255, 299);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 21);
            this.label4.TabIndex = 12;
            this.label4.Text = "NO";
            // 
            // Noradio
            // 
            this.Noradio.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Noradio.CheckedState.BorderThickness = 0;
            this.Noradio.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Noradio.CheckedState.InnerColor = System.Drawing.Color.White;
            this.Noradio.Location = new System.Drawing.Point(224, 295);
            this.Noradio.Name = "Noradio";
            this.Noradio.Size = new System.Drawing.Size(25, 25);
            this.Noradio.TabIndex = 11;
            this.Noradio.Text = "guna2CustomRadioButton2";
            this.Noradio.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Noradio.UncheckedState.BorderThickness = 2;
            this.Noradio.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.Noradio.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // DeleteroomBtn
            // 
            this.DeleteroomBtn.Location = new System.Drawing.Point(269, 435);
            this.DeleteroomBtn.Name = "DeleteroomBtn";
            this.DeleteroomBtn.Size = new System.Drawing.Size(102, 30);
            this.DeleteroomBtn.TabIndex = 22;
            this.DeleteroomBtn.Text = "DELETE";
            this.DeleteroomBtn.UseVisualStyleBackColor = true;
            this.DeleteroomBtn.Click += new System.EventHandler(this.DeleteroomBtn_Click);
            // 
            // Editroombtn
            // 
            this.Editroombtn.Location = new System.Drawing.Point(171, 435);
            this.Editroombtn.Name = "Editroombtn";
            this.Editroombtn.Size = new System.Drawing.Size(75, 30);
            this.Editroombtn.TabIndex = 21;
            this.Editroombtn.Text = "EDIT";
            this.Editroombtn.UseVisualStyleBackColor = true;
            this.Editroombtn.Click += new System.EventHandler(this.Editroombtn_Click);
            // 
            // AddroomBtn
            // 
            this.AddroomBtn.Location = new System.Drawing.Point(70, 435);
            this.AddroomBtn.Name = "AddroomBtn";
            this.AddroomBtn.Size = new System.Drawing.Size(75, 30);
            this.AddroomBtn.TabIndex = 20;
            this.AddroomBtn.Text = "ADD";
            this.AddroomBtn.UseVisualStyleBackColor = true;
            this.AddroomBtn.Click += new System.EventHandler(this.AddroomBtn_Click);
            // 
            // reloadbtn
            // 
            this.reloadbtn.Location = new System.Drawing.Point(796, 121);
            this.reloadbtn.Name = "reloadbtn";
            this.reloadbtn.Size = new System.Drawing.Size(117, 37);
            this.reloadbtn.TabIndex = 26;
            this.reloadbtn.Text = "RELOAD";
            this.reloadbtn.UseVisualStyleBackColor = true;
            this.reloadbtn.Click += new System.EventHandler(this.reloadbtn_Click);
            // 
            // RoomSearchtb
            // 
            this.RoomSearchtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RoomSearchtb.Location = new System.Drawing.Point(456, 121);
            this.RoomSearchtb.Multiline = true;
            this.RoomSearchtb.Name = "RoomSearchtb";
            this.RoomSearchtb.Size = new System.Drawing.Size(236, 38);
            this.RoomSearchtb.TabIndex = 25;
            this.RoomSearchtb.Text = "RoomSearch";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(689, 121);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(90, 38);
            this.button4.TabIndex = 24;
            this.button4.Text = "SEARCH";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // RoomGridView
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.RoomGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.RoomGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.RoomGridView.ColumnHeadersHeight = 4;
            this.RoomGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.RoomGridView.DefaultCellStyle = dataGridViewCellStyle3;
            this.RoomGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.RoomGridView.Location = new System.Drawing.Point(456, 165);
            this.RoomGridView.Name = "RoomGridView";
            this.RoomGridView.RowHeadersVisible = false;
            this.RoomGridView.RowHeadersWidth = 62;
            this.RoomGridView.RowTemplate.Height = 28;
            this.RoomGridView.Size = new System.Drawing.Size(743, 438);
            this.RoomGridView.TabIndex = 23;
            this.RoomGridView.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.RoomGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.RoomGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.RoomGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.RoomGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.RoomGridView.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.RoomGridView.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.RoomGridView.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.RoomGridView.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.RoomGridView.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RoomGridView.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.RoomGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.RoomGridView.ThemeStyle.HeaderStyle.Height = 4;
            this.RoomGridView.ThemeStyle.ReadOnly = false;
            this.RoomGridView.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.RoomGridView.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.RoomGridView.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RoomGridView.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.RoomGridView.ThemeStyle.RowsStyle.Height = 28;
            this.RoomGridView.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.RoomGridView.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.RoomGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.RoomGridView_CellContentClick);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(171, 557);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 30);
            this.button1.TabIndex = 34;
            this.button1.Text = "BACK";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // RoomInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1233, 632);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.reloadbtn);
            this.Controls.Add(this.RoomSearchtb);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.RoomGridView);
            this.Controls.Add(this.DeleteroomBtn);
            this.Controls.Add(this.Editroombtn);
            this.Controls.Add(this.AddroomBtn);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Noradio);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Yesradio);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Roomnametb);
            this.Controls.Add(this.Roomnumtbl);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "RoomInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RoomInfo";
            this.Load += new System.EventHandler(this.RoomInfo_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.RoomGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label Datelbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Roomnametb;
        private System.Windows.Forms.TextBox Roomnumtbl;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2CustomRadioButton Yesradio;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2CustomRadioButton Noradio;
        private System.Windows.Forms.Button DeleteroomBtn;
        private System.Windows.Forms.Button Editroombtn;
        private System.Windows.Forms.Button AddroomBtn;
        private System.Windows.Forms.Button reloadbtn;
        private System.Windows.Forms.TextBox RoomSearchtb;
        private System.Windows.Forms.Button button4;
        private Guna.UI2.WinForms.Guna2DataGridView RoomGridView;
        private System.Windows.Forms.Button button1;
    }
}