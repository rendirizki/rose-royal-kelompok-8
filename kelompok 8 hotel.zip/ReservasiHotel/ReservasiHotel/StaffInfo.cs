﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ReservasiHotel
{
    public partial class StaffInfo : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\asus\Documents\Hoteldb.mdf;Integrated Security=True;Connect Timeout=30");

        public void populate()
        {
            Con.Open();
            String Myquery = "select * from Staff_tbl";
            SqlDataAdapter da = new SqlDataAdapter(Myquery, Con);
            SqlCommandBuilder cbuilder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            StaffGridView.DataSource = ds.Tables[0];
            Con.Close();
        }

        public StaffInfo()
        {
            InitializeComponent();
        }

        private void StaffInfo_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            Con.Open();
            SqlCommand cmd = new SqlCommand("insert into Staff_tbl values(" + staffidtbl.Text + ",'" + staffnametb.Text + "','" + staffphonetb.Text + "','" + staffgender.SelectedItem.ToString() + "' ,'" + passwordtb.Text +"')", Con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Staff Susccessfully Added");
            Con.Close();
            populate();
        }

        private void StaffEditbtn_Click(object sender, EventArgs e)
        {
            Con.Open();
            string myquery = "UPDATE Staff_tbl set Staffname ='" + staffnametb.Text + "', staffphone = '" + staffphonetb.Text + "', Staffpassword = '" + passwordtb.Text + "', gender = '" + staffgender.SelectedItem.ToString() + "' where StaffId = " + staffidtbl.Text + ";";
            SqlCommand cmd = new SqlCommand(myquery, Con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Client Successfully Edited");
            Con.Close();
            populate();
        }

        private void StaffGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            staffidtbl.Text = StaffGridView.SelectedRows[0].Cells[0].Value.ToString();
            staffnametb.Text = StaffGridView.SelectedRows[0].Cells[1].Value.ToString();
            staffphonetb.Text = StaffGridView.SelectedRows[0].Cells[2].Value.ToString();
            passwordtb.Text = StaffGridView.SelectedRows[0].Cells[4].Value.ToString();
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            Con.Open();
            string query = "delete from Staff_tbl where StaffId = " + staffidtbl.Text + "";
            SqlCommand cmd = new SqlCommand(query, Con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Staff Succecfully Deleted");
            Con.Close();
            populate();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Con.Open();
            String Myquery = "select * from Staff_tbl where Staffname = '" + StaffSearchtb.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(Myquery, Con);
            SqlCommandBuilder cbuilder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            StaffGridView.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void reloadbtn_Click(object sender, EventArgs e)
        {
            populate();
        }

        private void StaffSearchtb_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MainForm main = new MainForm();
            main.Show();
            this.Hide();
        }
    }
}
