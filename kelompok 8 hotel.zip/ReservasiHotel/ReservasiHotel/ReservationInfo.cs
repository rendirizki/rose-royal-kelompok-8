﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace ReservasiHotel
{
    public partial class ReservationInfo : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\asus\Documents\Hoteldb.mdf;Integrated Security=True;Connect Timeout=30");

        public ReservationInfo()
        {
            InitializeComponent();
        }

        public void populate()
        {
            Con.Open();
            String Myquery = "select * from Reservation_tbl";
            SqlDataAdapter da = new SqlDataAdapter(Myquery, Con);
            SqlCommandBuilder cbuilder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            ReservationGridView.DataSource = ds.Tables[0];
            Con.Close();
        }

        DateTime today;
        private void ReservationInfo_Load(object sender, EventArgs e)
        {
            today = DateIn.Value;
            fillRoomCombo();
            fillClientCombo();
            populate(); 
        }

        private void fillRoomCombo()
        {
            Con.Open();
            string Roomstate = "free";
            SqlCommand cmd = new SqlCommand("Select RoomId from Room_tbl where RoomFree = '" + Roomstate + "'", Con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("RoomnId", typeof(int));
            dt.Load(rdr);   
            Roomcb.ValueMember = "RoomId";
            Roomcb.DataSource = dt;
            Con.Close();

        }

        private void fillClientCombo()
        {
            Con.Open();
            SqlCommand cmd = new SqlCommand("Select ClientName from Client_tbl", Con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("ClientName", typeof(string));
            dt.Load(rdr);
            Clientcb.ValueMember = "ClientName";
            Clientcb.DataSource = dt;
            Con.Close();
        }

        private void DateIn_ValueChanged(object sender, EventArgs e)
        {
            int res = DateTime.Compare(DateIn.Value, today);
            if (res < 0)
                MessageBox.Show("Wrong Date For Reservation");
        }

        private void DateOut_ValueChanged(object sender, EventArgs e)
        {
            int res = DateTime.Compare(DateOut.Value, DateIn.Value);
            if (res < 0)
                MessageBox.Show("Wrong Dateout, check once more");
        }

        private void updateRoomstate()
        {
            Con.Open();
            string newstate = "busy";
            string myquery = "UPDATE Room_tbl set RoomFree ='" + newstate + "' where RoomId = " +Convert.ToInt32(Roomcb.SelectedValue.ToString()) + ";";
            SqlCommand cmd = new SqlCommand(myquery, Con);
            cmd.ExecuteNonQuery();
            //MessageBox.Show("Reservation Successfully Edited");
            Con.Close();
            fillRoomCombo();
        }

        private void updateRoomondelete()
        {
            Con.Open();
            string newstate = "free";
            int roomid = Convert.ToInt32(ReservationGridView.SelectedRows[0].Cells[2].Value.ToString());
            string myquery = "UPDATE Room_tbl set RoomFree ='" + newstate + "' where RoomId = " + roomid + ";";
            SqlCommand cmd = new SqlCommand(myquery, Con);
            cmd.ExecuteNonQuery();
            //MessageBox.Show("Reservation Successfully Edited");
            Con.Close();
            fillRoomCombo();
        }

        private void AddroomBtn_Click(object sender, EventArgs e)
        {
            Con.Open();
            SqlCommand cmd = new SqlCommand("insert into Reservation_tbl values(" + ReserIdtb.Text + ",'" + Clientcb.SelectedValue.ToString() + "', '" + Roomcb.SelectedValue.ToString() + "','" + DateIn.Text + "','" + DateOut.Text + "')", Con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Reservation Susccessfully Added");
            Con.Close();
            updateRoomstate();
            populate();
        }

        private void ReservationGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ReserIdtb.Text = ReservationGridView.SelectedRows[0].Cells[0].Value.ToString();
        }

        private void DeleteroomBtn_Click(object sender, EventArgs e)
        {
            if (ReserIdtb.Text == "")
            {
                MessageBox.Show("Enter the Reservation to be delete");
            }
            else
            {
                Con.Open();
                string query = "delete from Reservation_tbl where ResId = " + ReserIdtb.Text + "";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Reservation Succecfully Deleted");
                Con.Close();
                updateRoomondelete();
                populate(); 
            }
        }
        

        private void Editroombtn_Click(object sender, EventArgs e)
        {
            if (ReserIdtb.Text == " ")
            {
                MessageBox.Show("Empty ResId, Enter The Reservation Id ");
            }
            else
            {
                Con.Open();
                string myquery = "UPDATE Reserv ation_tbl set Client ='" + Clientcb.SelectedValue.ToString() + "', Room = '" + Roomcb.SelectedValue.ToString() + "', DateIn = '" + DateIn.Value.ToString() + "', DateOut = '" + DateOut.Value.ToString() + "' where ResId = " + ReserIdtb.Text + ";";
                SqlCommand cmd = new SqlCommand(myquery, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Reservation Successfully Edited");
                Con.Close();
                populate();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Con.Open();
            String Myquery = "select * from Reservation_tbl where ResId = '" + ReservationSearchtb.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(Myquery, Con);
            SqlCommandBuilder cbuilder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            ReservationGridView.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void reloadbtn_Click(object sender, EventArgs e)
        {
            populate();
        }

        private void Roomcb_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MainForm main = new MainForm();
            main.Show();
            this.Hide();
        }
    }
}
